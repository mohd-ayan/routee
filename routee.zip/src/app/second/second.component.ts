import { Component, OnInit } from '@angular/core';
import {ActivatedRoute} from "@angular/router";

@Component({
  selector: 'app-second',
  templateUrl: './second.component.html',
  styleUrls: ['./second.component.css']
})
export class SecondComponent implements OnInit {

  constructor(public route:ActivatedRoute) {
  }

  ngOnInit(): void {
  }

  hideedu()
  {
    let a = document.getElementById('edu') as HTMLElement
    a.style.display="none"
  }


  Showedu()
  {
    let a = document.getElementById('edu') as HTMLElement
    a.style.display="block"
  }


  hideexp()
  {
    let a = document.getElementById('exp') as HTMLElement
    a.style.display="none"
  }

  showexp()
  {
    let a = document.getElementById('exp') as HTMLElement
    a.style.display="block"
  }
}
