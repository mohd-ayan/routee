import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import {SecondComponent} from "./second/second.component";
import {FirstComponent} from "./first/first.component";
import {AppComponent} from "./app.component";
import {RouteComponent} from "./route/route.component";
import {ForgotComponent} from "./forgot/forgot.component";

const routes: Routes = [
  {path: 'second',
    component: SecondComponent,
  },
  {path: 'first',
    component: FirstComponent,
  },
  {path: '',
    component: RouteComponent,
  },
  {
    path:'forgot',
    component:ForgotComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
